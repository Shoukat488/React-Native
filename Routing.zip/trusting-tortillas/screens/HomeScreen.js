import React from 'react';
import {
  Text,
  TouchableOpacity,
  View,StyleSheet
} from 'react-native';


export default function HomeScreen(props) {
  return (
    <View style = {styles.container} >
      <TouchableOpacity style = {styles.myButton} onPress = {()=>{ props.navigation.navigate('List')}}>
        <Text>My list</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({

  container:
  {
    flexDirection:'row',
    justifyContent:"center",
    alignItems:"center"
  },
  myButton:{
    backgroundColor:'green'
  }
})
