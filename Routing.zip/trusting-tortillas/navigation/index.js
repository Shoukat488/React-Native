import React from 'react';
import {createAppContainer , createSwitchNavigator} from 'react-navigation';
import ReactDrawer from './DrawerReact';

const AppContainer = createAppContainer(
  createSwitchNavigator({
    Main : ReactDrawer
  })
)

export default AppContainer;
