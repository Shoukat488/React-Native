import React from 'react';
import { createBottomTabNavigator } from 'react-navigation-tabs';
import HomeStack from '../screens/HomeScreen';
import LinkStack from '../screens/LinksScreen';
import SettingStack from '../screens/SettingsScreen';

const TabNavigator = createBottomTabNavigator({
  HomeStack,
  LinkStack,
  SettingStack
},
{
  
  tabBarOptions :{
    showLabel : 'false',
    safeAreaInSet : {top :"never" , bottom: 'never'}
  },

  inititalRouteName: "HomeStack"
}

)

export {TabNavigator}