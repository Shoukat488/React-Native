import React from 'react';
import { createDrawerNavigator } from 'react-navigation-drawer';
import{ Dimensions } from 'react-native';
import TabNaivgator from './TabNavigator';
import sideBar from '../screens/sideBar';
const ReactDrawer = createDrawerNavigator({
  Tabs : TabNaivgator
},
{
  inititalRouteName: "Tabs",
  contentComponent : sideBar,
  drawerWidth : (Dimensions.get('screen').width /1.3),
  drawerPosition : 'right',
  overlayColor : "rgba(0,0,0,0.4)",
  statusBarAnimation: "none",
  drawerLockMode: 'locked-closed',
  drawerType: 'front',
});

export {ReactDrawer}