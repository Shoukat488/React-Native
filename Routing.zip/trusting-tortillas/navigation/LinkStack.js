import React from 'react';
import { createStackNavigator } from 'react-navigation-stack';
import Link from '../screens/LinksScreen';
import { Ionicons } from '@expo/vector-icons';
import Colors from '../constants/Colors';
const LinkStack = createStackNavigator({
  Link
},
{
  defaultNavigationOPtions :{
    headerStyle : {},
    headerForceInset : {top : 'never'}
  }
}
)

LinkStack.navigationOptions ={
  tabBarLabel : 'Home',
  tabBarIcon : ({focused})=>{
    <Ionicons
    focus = {focused}
    name = "ios-home"
    size = {26}
    Color ={focused ? Colors.tabIconSelected : Colors.tabIconDefault}
     />
  }
}