import React from 'react';
import { createStackNavigator } from 'react-navigation-stack';
import { Ionicons } from '@expo/vector-icons';
import Home from '../screens/HomeScreen';
import List from '../screens/list';
import Colors from '../constants/Colors';
const HomeStack = createStackNavigator(
  {
    Home,
    List
  },
  {
    defaultNavigationOptions:{
      headerStyle : {},
      headerForceInset : {top : 'never'}
    }
  }
);

HomeStack.navigationOptions = {
  tabBarLabel: 'Home',
  tabBarIcon: ({ focused }) => (
    <Ionicons
    focus = {focused}
    name = 'ios-home'
    size = {26}
    color= {focused ? Colors.tabIconSelected :  Colors.tabIconDefault}

     />
  ),
};
