import React from 'react';
import { createStackNavigator } from 'react-navigation-stack';
import Setting from '../screens/SettingsScreen';
import Colors from '../constants/Colors';
import { Ionicons } from '@expo/vector-icons';
const SettingStack = createStackNavigator({
  Setting
},
{
  defaultNavigationOptions:{
    headerStyle : {},
    headerForceInset : {top :'never'}
  }
}
)

SettingStack.navigaitonOptions ={
tabBarLabel : "Setting",
tabBarIcon :({focused})=>{
  <Ionicons
  focuse = {focused}
  name = 'ios-home'
  size = {26}
 color= {focused ? Colors.tabIconSelected :  Colors.tabIconDefault}
   />
}
}

export {SettingStack}


