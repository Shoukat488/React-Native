import React from 'react';
import {View , Text , StyleSheet}  from 'react-native';

const List=()=>{


  return(

    <View style = {styles.container}>
    <Text> MY List </Text>
    </View>
  )
}

export default List;

export const styles = StyleSheet.create({
  container: {
    alignItems : 'center',
    justifyContent : 'center'
  }

})